<section
class="has_eae_slider elementor-section elementor-top-section elementor-element elementor-element-19c4d18 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
data-id="19c4d18" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
  <div
    class="has_eae_slider elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-75042d8"
    data-id="75042d8" data-element_type="column">
    <div class="elementor-widget-wrap elementor-element-populated">
      <div
        class="elementor-element elementor-element-9819eb8 eae-icon-view-default elementor-widget elementor-widget-wts-textseparator"
        data-id="9819eb8" data-element_type="widget" data-widget_type="wts-textseparator.default">
        <div class="elementor-widget-container">
          <div class="wts-eae-textseparator sep-align-center icon-yes icon-before title-yes">
            <div class="eae-sep-holder sep-left">
              <div class="eae-sep-lines"></div>
            </div>


            <h2 class="eae-separator-title">Наш цех</h2>

            <div class="eae-sep-holder sep-right">
              <div class="eae-sep-lines"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</section>

<section
class="has_eae_slider elementor-section elementor-top-section elementor-element elementor-element-66df8f3b elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default"
data-id="66df8f3b" data-element_type="section"
data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-background-overlay"></div>
<div class="elementor-container elementor-column-gap-default">
  <div
    class="has_eae_slider elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7e4d28bf"
    data-id="7e4d28bf" data-element_type="column">
    <div class="elementor-widget-wrap elementor-element-populated">
      <div
        class="elementor-element elementor-element-6aede417 elementor-widget elementor-widget-text-editor"
        data-id="6aede417" data-element_type="widget" data-widget_type="text-editor.default">
        <div class="elementor-widget-container">
        </div>
      </div>
      <div class="elementor-element elementor-element-3dbd6eb2 elementor-widget elementor-widget-spacer"
        data-id="3dbd6eb2" data-element_type="widget" data-widget_type="spacer.default">
        <div class="elementor-widget-container">
          <div class="elementor-spacer">
            <div class="elementor-spacer-inner"></div>
          </div>
        </div>
      </div>
      <div
        class="elementor-element elementor-element-1cf89ff8 elementor-arrows-position-outside elementor-widget elementor-widget-image-carousel"
        data-id="1cf89ff8" data-element_type="widget"
        data-settings="{&quot;slides_to_show&quot;:&quot;3&quot;,&quot;navigation&quot;:&quot;arrows&quot;,&quot;image_spacing_custom&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;20&quot;,&quot;sizes&quot;:[]},&quot;autoplay&quot;:&quot;yes&quot;,&quot;pause_on_hover&quot;:&quot;yes&quot;,&quot;pause_on_interaction&quot;:&quot;yes&quot;,&quot;autoplay_speed&quot;:5000,&quot;infinite&quot;:&quot;yes&quot;,&quot;speed&quot;:500}"
        data-widget_type="image-carousel.default">
        <div class="elementor-widget-container">
          <div class="elementor-image-carousel-wrapper swiper-container gal-swiper-container" dir="ltr">

            <div class="elementor-image-carousel swiper-wrapper">
              <div class="swiper-slide"><a data-fslightbox="sg1"
                  href="img/big_pict/slide_1_big.jpg">
                  <figure class="swiper-slide-inner"><img class="swiper-slide-image"
                      src="img/slider-1.jpg"
                      alt="IMG_2571-min" /></figure>
                </a></div>
              <div class="swiper-slide"><a data-fslightbox="sg1"
                  href="img/big_pict/slide_2_big.jpg">
                  <figure class="swiper-slide-inner"><img class="swiper-slide-image"
                      src="img/slider-2.jpg"
                      alt="IMG_2524-min" /></figure>
                </a></div>
              <div class="swiper-slide"><a data-fslightbox="sg1"
                  href="img/big_pict/slide_3_big.jpg">
                  <figure class="swiper-slide-inner"><img class="swiper-slide-image"
                      src="img/slider-3.jpg"
                      alt="IMG_2526-min" /></figure>
                </a></div>
              <div class="swiper-slide"><a data-fslightbox="sg1"
                  href="img/big_pict/slide_4_big.jpg">
                  <figure class="swiper-slide-inner"><img class="swiper-slide-image"
                      src="img/slider-4.jpg"
                      alt="IMG_2528-min" /></figure>
                </a></div>
              <div class="swiper-slide"><a data-fslightbox="sg1"
                  href="img/big_pict/slide_5_big.jpg">
                  <figure class="swiper-slide-inner"><img class="swiper-slide-image"
                      src="img/slider-5.jpg"
                      alt="IMG_2530-min" /></figure>
                </a></div>
              <div class="swiper-slide"><a data-fslightbox="sg1"
                  href="img/big_pict/slide_6_big.jpg">
                  <figure class="swiper-slide-inner"><img class="swiper-slide-image"
                      src="img/slider-6.jpg"
                      alt="IMG_2531-min" /></figure>
                </a></div>
              <div class="swiper-slide"><a data-fslightbox="sg1"
                  href="img/big_pict/slide_7_big.jpg">
                  <figure class="swiper-slide-inner"><img class="swiper-slide-image"
                      src="img/slider-7.jpg"
                      alt="IMG_2541-min" /></figure>
                </a></div>
              <div class="swiper-slide"><a data-fslightbox="sg1"
                  href="img/big_pict/slide_8_big.jpg">
                  <figure class="swiper-slide-inner"><img class="swiper-slide-image"
                      src="img/slider-8.jpg"
                      alt="IMG_2544-min" /></figure>
                </a></div>
              <div class="swiper-slide"><a data-fslightbox="sg1"
                  href="img/big_pict/slide_9_big.jpg">
                  <figure class="swiper-slide-inner"><img class="swiper-slide-image"
                      src="img/slider-9.jpg"
                      alt="IMG_2550-min" /></figure>
                </a></div>
              <div class="swiper-slide"><a data-fslightbox="sg1"
                  href="img/big_pict/slide_10_big.jpg">
                  <figure class="swiper-slide-inner"><img class="swiper-slide-image"
                      src="img/slider-10.jpg"
                      alt="IMG_2564-min" /></figure>
                </a></div>
              <div class="swiper-slide"><a data-fslightbox="sg1"
                  href="img/big_pict/slide_11_big.jpg">
                  <figure class="swiper-slide-inner"><img class="swiper-slide-image"
                      src="img/slider-11.jpg"
                      alt="IMG_2565-min" /></figure>
                </a></div>
              <div class="swiper-slide"><a data-fslightbox="sg1"
                  href="img/big_pict/slide_12_big.jpg">
                  <figure class="swiper-slide-inner"><img class="swiper-slide-image"
                      src="img/slider-12.jpg"
                      alt="IMG_2567-min" /></figure>
                </a></div>

            </div>
            <div id="bb_prev" class="elementor-swiper-button elementor-swiper-button-prev">
              <i aria-hidden="true" class="fa fa-chevron-left"></i> <span
                class="elementor-screen-only">Назад</span>
            </div>
            <div id="bb_next" class="elementor-swiper-button elementor-swiper-button-next">
              <i aria-hidden="true" class="fa fa-chevron-right"></i> <span
                class="elementor-screen-only">Далее</span>
            </div>
          </div>
        </div>
      </div>
      <div class="elementor-element elementor-element-385df4fa elementor-widget elementor-widget-spacer"
        data-id="385df4fa" data-element_type="widget" data-widget_type="spacer.default">
        <div class="elementor-widget-container">
          <div class="elementor-spacer">
            <div class="elementor-spacer-inner"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</section>
