<section
class="has_eae_slider elementor-section elementor-top-section elementor-element elementor-element-69cc37c elementor-section-boxed elementor-section-height-default elementor-section-height-default"
data-id="69cc37c" data-element_type="section"
data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
  <div
    class="has_eae_slider elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-7f34ef4"
    data-id="7f34ef4" data-element_type="column">
    <div class="elementor-widget-wrap elementor-element-populated">

      <section
        class="has_eae_slider elementor-section elementor-inner-section elementor-element elementor-element-39db23c elementor-section-boxed elementor-section-height-default elementor-section-height-default"
        data-id="39db23c" data-element_type="section">
        <div class="elementor-container elementor-column-gap-default">
          <div
            class="has_eae_slider elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-47cdb91"
            data-id="47cdb91" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
              <div
                class="elementor-element elementor-element-b9e0daf elementor-widget elementor-widget-heading"
                data-id="b9e0daf" data-element_type="widget" data-widget_type="heading.default">
                <div class="elementor-widget-container">
                  <h2 class="elementor-heading-title elementor-size-default">Ваш двигатель в надежных
                    руках</h2>
                </div>
              </div>
              <div
                class="elementor-element elementor-element-1fcaa22 elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                data-id="1fcaa22" data-element_type="widget" data-widget_type="divider.default">
                <div class="elementor-widget-container">
                  <div class="elementor-divider">
                    <span class="elementor-divider-separator">
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

    </div>
  </div>
  <div
    class="has_eae_slider elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-664ab00"
    data-id="664ab00" data-element_type="column">
    <div class="elementor-widget-wrap elementor-element-populated">

      <section
        class="has_eae_slider elementor-section elementor-inner-section elementor-element elementor-element-47f74dd elementor-section-boxed elementor-section-height-default elementor-section-height-default"
        data-id="47f74dd" data-element_type="section">
        <div class="elementor-container elementor-column-gap-default">
          <div
            class="has_eae_slider elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-3a0835b"
            data-id="3a0835b" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
              <div
                class="elementor-element elementor-element-fd6ba54 elementor-widget elementor-widget-text-editor"
                data-id="fd6ba54" data-element_type="widget" data-widget_type="text-editor.default">
                <div class="elementor-widget-container">
                  <p>Доверьте <span style="color: #ff0000;">сердце</span> вашего автомобиля профессионалам
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div
            class="has_eae_slider elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-123a46b"
            data-id="123a46b" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
              <div
                class="elementor-element elementor-element-0d586f3 elementor-widget elementor-widget-image"
                data-id="0d586f3" data-element_type="widget" data-widget_type="image.default">
                <div class="elementor-widget-container">
                  <img width="1024" height="640"
                    src="img/mator-1.jpg"
                    class="attachment-large size-large" alt="" loading="lazy"
                    srcset="img/mator-1.jpg 1024w, img/mator-1.jpg 300w, img/mator-1.jpg 768w, img/mator-1.jpg 1920w"
                    sizes="(max-width: 1024px) 100vw, 1024px" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

    </div>
  </div>
</div>
</section>