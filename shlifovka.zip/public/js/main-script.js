var swiper = new Swiper(".gal-swiper-container", {
    slidesPerView: 3,
    spaceBetween: 30,

    navigation: {
      nextEl: "#bb_next",
      prevEl: "#bb_prev",
    },
  });
