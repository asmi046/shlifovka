<section
class="has_eae_slider elementor-section elementor-top-section elementor-element elementor-element-212cc13e elementor-section-height-min-height elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-items-middle"
data-id="212cc13e" data-element_type="section"
data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-background-overlay"></div>
<div class="elementor-container elementor-column-gap-default">
  <div
    class="has_eae_slider elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-3efcd42a"
    data-id="3efcd42a" data-element_type="column"
    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
    <div class="elementor-widget-wrap elementor-element-populated">
      <div class="elementor-element elementor-element-a662231 elementor-widget elementor-widget-heading"
        data-id="a662231" data-element_type="widget" data-widget_type="heading.default">
        <div class="elementor-widget-container">
          <h2 class="elementor-heading-title elementor-size-default">Шлифовка</h2>
        </div>
      </div>
      <div
        class="elementor-element elementor-element-5796ec5 elementor-widget elementor-widget-text-editor"
        data-id="5796ec5" data-element_type="widget" data-widget_type="text-editor.default">
        <div class="elementor-widget-container">
          <p>Это технический центр в Курске,<br />специализирующийся на ремонтах деталей двигателя с
            легковых и грузовых автомобилей</p>
        </div>
      </div>
    </div>
  </div>
</div>
</section><?php /**PATH C:\Users\LisaN\Documents\GitHub\shlifovka\resources\views/part/mainheader.blade.php ENDPATH**/ ?>