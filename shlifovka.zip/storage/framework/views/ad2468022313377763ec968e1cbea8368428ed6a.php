<section
              class="has_eae_slider elementor-section elementor-top-section elementor-element elementor-element-acaff54 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
              data-id="acaff54" data-element_type="section"
              data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
              <div class="elementor-container elementor-column-gap-default">
                <div
                  class="has_eae_slider elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-cccb7da"
                  data-id="cccb7da" data-element_type="column">
                  <div class="elementor-widget-wrap elementor-element-populated">

                    <section
                      class="has_eae_slider elementor-section elementor-inner-section elementor-element elementor-element-48e0a5d elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                      data-id="48e0a5d" data-element_type="section">
                      <div class="elementor-container elementor-column-gap-default">
                        <div
                          class="has_eae_slider elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-155be8c"
                          data-id="155be8c" data-element_type="column">
                          <div class="elementor-widget-wrap elementor-element-populated">
                            <div
                              class="elementor-element elementor-element-b73a4ba elementor-widget elementor-widget-heading"
                              data-id="b73a4ba" data-element_type="widget" data-widget_type="heading.default">
                              <div class="elementor-widget-container">
                                <h2 class="elementor-heading-title elementor-size-default">Автозапчасти в наличии</h2>
                              </div>
                            </div>
                            <div
                              class="elementor-element elementor-element-12fc38e elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                              data-id="12fc38e" data-element_type="widget" data-widget_type="divider.default">
                              <div class="elementor-widget-container">
                                <div class="elementor-divider">
                                  <span class="elementor-divider-separator">
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </section>

                  </div>
                </div>
                <div
                  class="has_eae_slider elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-11a6f36"
                  data-id="11a6f36" data-element_type="column">
                  <div class="elementor-widget-wrap elementor-element-populated">
                    <section
                      class="has_eae_slider elementor-section elementor-inner-section elementor-element elementor-element-5e6b42b elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                      data-id="5e6b42b" data-element_type="section">
                      <div class="elementor-container elementor-column-gap-default">
                        <div
                          class="has_eae_slider elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-6b15413"
                          data-id="6b15413" data-element_type="column">
                          <div class="elementor-widget-wrap elementor-element-populated">
                            <div
                              class="elementor-element elementor-element-97a398d elementor-widget elementor-widget-text-editor"
                              data-id="97a398d" data-element_type="widget" data-widget_type="text-editor.default">
                              <div class="elementor-widget-container">
                                <p>ГАЗ</p>
                                <p>ВАЗ</p>
                                <p>МАЗ</p>
                                <p>КАМАЗ</p>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div
                          class="has_eae_slider elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-68f5d78"
                          data-id="68f5d78" data-element_type="column">
                          <div class="elementor-widget-wrap elementor-element-populated">
                            <div
                              class="elementor-element elementor-element-ad518a0 elementor-widget elementor-widget-image"
                              data-id="ad518a0" data-element_type="widget" data-widget_type="image.default">
                              <div class="elementor-widget-container">
                                <img width="1024" height="622"
                                  src="img/mator-2.jpg"
                                  class="attachment-large size-large" alt="" loading="lazy"
                                  srcset="img/mator-2.jpg 1024w, img/mator-2.jpg 300w, img/mator-2.jpg 768w, img/mator-2.jpg 1680w"
                                  sizes="(max-width: 1024px) 100vw, 1024px" />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </section>
                  </div>
                </div>
              </div>
            </section><?php /**PATH C:\Users\LisaN\Documents\GitHub\shlifovka\resources\views/part/zap.blade.php ENDPATH**/ ?>