
            <section
            class="has_eae_slider elementor-section elementor-top-section elementor-element elementor-element-74771749 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="74771749" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
              <div
                class="has_eae_slider elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-1613671e"
                data-id="1613671e" data-element_type="column">
                <div class="elementor-widget-wrap elementor-element-populated">
                  <div class="elementor-element elementor-element-5c2a6be2 elementor-widget elementor-widget-heading"
                    data-id="5c2a6be2" data-element_type="widget" data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                      <h2 class="elementor-heading-title elementor-size-large">Контакты</h2>
                    </div>
                  </div>
                  <div
                    class="elementor-element elementor-element-5de43562 elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                    data-id="5de43562" data-element_type="widget" data-widget_type="divider.default">
                    <div class="elementor-widget-container">
                      <div class="elementor-divider">
                        <span class="elementor-divider-separator">
                        </span>
                      </div>
                    </div>
                  </div>
                  <div
                    class="elementor-element elementor-element-3840a1dc elementor-align-center elementor-mobile-align-center elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                    data-id="3840a1dc" data-element_type="widget" data-widget_type="icon-list.default">
                    <div class="elementor-widget-container">
                      <ul class="elementor-icon-list-items">
                        <li class="elementor-icon-list-item">
                          <span class="elementor-icon-list-icon">
                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                          </span>
                          <span class="elementor-icon-list-text">г. Курск, 1-я Моква, ул. Санаторная, д2</span>
                        </li>
                        <li class="elementor-icon-list-item">
                          <span class="elementor-icon-list-icon">
                            <i class="fa fa-envelope-square" aria-hidden="true"></i>
                          </span>
                          <span class="elementor-icon-list-text">KVAKURSK@mail.ru</span>
                        </li>
                        <li class="elementor-icon-list-item">
                          <span class="elementor-icon-list-icon">
                            <i class="fa fa-phone-square" aria-hidden="true"></i>
                          </span>
                          <span class="elementor-icon-list-text">8-(4712)-32-48-30</span>
                        </li>
                        <li class="elementor-icon-list-item">
                          <span class="elementor-icon-list-icon">
                            <i class="fa fa-fax" aria-hidden="true"></i>
                          </span>
                          <span class="elementor-icon-list-text">8-910-731-10-07</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section><?php /**PATH C:\Users\LisaN\Documents\GitHub\shlifovka\resources\views/part/contacts_in_main.blade.php ENDPATH**/ ?>