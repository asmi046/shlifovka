<section
class="has_eae_slider elementor-section elementor-top-section elementor-element elementor-element-df31132 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
data-id="df31132" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
  <div
    class="has_eae_slider elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-83a8061"
    data-id="83a8061" data-element_type="column">
    <div class="elementor-widget-wrap elementor-element-populated">
      <div
        class="elementor-element elementor-element-114c132 eae-icon-view-default elementor-widget elementor-widget-wts-textseparator"
        data-id="114c132" data-element_type="widget" data-widget_type="wts-textseparator.default">
        <div class="elementor-widget-container">
          <div class="wts-eae-textseparator sep-align-center icon-yes icon-before title-yes">
            <div class="eae-sep-holder sep-left">
              <div class="eae-sep-lines"></div>
            </div>


            <h2 class="eae-separator-title">Виды работ</h2>

            <div class="eae-sep-holder sep-right">
              <div class="eae-sep-lines"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</section>

<section
class="has_eae_slider elementor-section elementor-top-section elementor-element elementor-element-7ed4dcf elementor-section-boxed elementor-section-height-default elementor-section-height-default"
data-id="7ed4dcf" data-element_type="section"
data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
  <div
    class="has_eae_slider elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-a766660"
    data-id="a766660" data-element_type="column">
    <div class="elementor-widget-wrap elementor-element-populated">
      <div
        class="elementor-element elementor-element-3febb83 eae-fb-animate-fade elementor-widget elementor-widget-wts-flipbox"
        data-id="3febb83" data-element_type="widget" data-widget_type="wts-flipbox.default">
        <div class="elementor-widget-container">
          <div class="eae-flip-box-wrapper">
            <div class="eae-flip-box-inner" onclick="">

              <div class="eae-flip-box-front">
                <div class="flipbox-content">
                  <div class="icon-wrapper eae-fb-icon-view-default eae-fb-icon-shape-">
                    <i aria-hidden="true" class="fas fa-star"></i>
                  </div>

                  <h3 class="front-icon-title">Ремонт двигателей</h3>
                </div>
              </div>

              <div class="eae-flip-box-back">
                <div class="flipbox-content">
                  <div class="icon-wrapper eae-fb-icon-view-default eae-fb-icon-shape-">
                    <i aria-hidden="true" class="fas fa-star"></i>
                  </div>

                  <h3 class="back-icon-title">Ремонт двигателя</h3>

                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div
    class="has_eae_slider elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-163d230"
    data-id="163d230" data-element_type="column">
    <div class="elementor-widget-wrap elementor-element-populated">
      <div
        class="elementor-element elementor-element-5d99ea8 eae-fb-animate-fade elementor-widget elementor-widget-wts-flipbox"
        data-id="5d99ea8" data-element_type="widget" data-widget_type="wts-flipbox.default">
        <div class="elementor-widget-container">
          <div class="eae-flip-box-wrapper">
            <div class="eae-flip-box-inner" onclick="">

              <div class="eae-flip-box-front">
                <div class="flipbox-content">
                  <div class="icon-wrapper eae-fb-icon-view-default eae-fb-icon-shape-">
                    <i aria-hidden="true" class="fas fa-star"></i>
                  </div>

                  <h3 class="front-icon-title">Фрезеровка блока целиндров</h3>
                </div>
              </div>

              <div class="eae-flip-box-back">
                <div class="flipbox-content">
                  <div class="icon-wrapper eae-fb-icon-view-default eae-fb-icon-shape-">
                    <i aria-hidden="true" class="fas fa-star"></i>
                  </div>

                  <h3 class="back-icon-title">Ремонт нижней части шатуна</h3>

                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</section>

<section
class="has_eae_slider elementor-section elementor-top-section elementor-element elementor-element-672785c elementor-section-boxed elementor-section-height-default elementor-section-height-default"
data-id="672785c" data-element_type="section"
data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
  <div
    class="has_eae_slider elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-4f282de"
    data-id="4f282de" data-element_type="column">
    <div class="elementor-widget-wrap elementor-element-populated">
      <div
        class="elementor-element elementor-element-584dc0c eae-fb-animate-fade elementor-widget elementor-widget-wts-flipbox"
        data-id="584dc0c" data-element_type="widget" data-widget_type="wts-flipbox.default">
        <div class="elementor-widget-container">
          <div class="eae-flip-box-wrapper">
            <div class="eae-flip-box-inner" onclick="">

              <div class="eae-flip-box-front">
                <div class="flipbox-content">
                  <div class="icon-wrapper eae-fb-icon-view-default eae-fb-icon-shape-">
                    <i aria-hidden="true" class="fas fa-star"></i>
                  </div>

                  <h3 class="front-icon-title">Ремонт коленвала</h3>
                </div>
              </div>

              <div class="eae-flip-box-back">
                <div class="flipbox-content">
                  <div class="icon-wrapper eae-fb-icon-view-default eae-fb-icon-shape-">
                    <i aria-hidden="true" class="fas fa-star"></i>
                  </div>

                  <h3 class="back-icon-title">Ремонт коленвала</h3>

                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div
    class="has_eae_slider elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-91c08b1"
    data-id="91c08b1" data-element_type="column">
    <div class="elementor-widget-wrap elementor-element-populated">
      <div
        class="elementor-element elementor-element-71d34d3 eae-fb-animate-fade elementor-widget elementor-widget-wts-flipbox"
        data-id="71d34d3" data-element_type="widget" data-widget_type="wts-flipbox.default">
        <div class="elementor-widget-container">
          <div class="eae-flip-box-wrapper">
            <div class="eae-flip-box-inner" onclick="">

              <div class="eae-flip-box-front">
                <div class="flipbox-content">
                  <div class="icon-wrapper eae-fb-icon-view-default eae-fb-icon-shape-">
                    <i aria-hidden="true" class="fas fa-star"></i>
                  </div>

                  <h3 class="front-icon-title">Ремонт постели распредвала</h3>
                </div>
              </div>

              <div class="eae-flip-box-back">
                <div class="flipbox-content">
                  <div class="icon-wrapper eae-fb-icon-view-default eae-fb-icon-shape-">
                    <i aria-hidden="true" class="fas fa-star"></i>
                  </div>

                  <h3 class="back-icon-title">Ремонт постели распредвала</h3>

                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</section><?php /**PATH C:\Users\LisaN\Documents\GitHub\shlifovka\resources\views/part/work_type.blade.php ENDPATH**/ ?>