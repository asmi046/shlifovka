<section
              class="has_eae_slider elementor-section elementor-top-section elementor-element elementor-element-0fd541e elementor-section-boxed elementor-section-height-default elementor-section-height-default"
              data-id="0fd541e" data-element_type="section">
              <div class="elementor-container elementor-column-gap-default">
                <div
                  class="has_eae_slider elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-ad18482"
                  data-id="ad18482" data-element_type="column">
                  <div class="elementor-widget-wrap elementor-element-populated">
                    <div
                      class="elementor-element elementor-element-b8e9926 eae-icon-view-default elementor-widget elementor-widget-wts-textseparator"
                      data-id="b8e9926" data-element_type="widget" data-widget_type="wts-textseparator.default">
                      <div class="elementor-widget-container">
                        <div class="wts-eae-textseparator sep-align-center icon-yes icon-before title-yes">
                          <div class="eae-sep-holder sep-left">
                            <div class="eae-sep-lines"></div>
                          </div>


                          <h2 class="eae-separator-title">Наши преимущества</h2>

                          <div class="eae-sep-holder sep-right">
                            <div class="eae-sep-lines"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section
              class="has_eae_slider elementor-section elementor-top-section elementor-element elementor-element-6068084 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
              data-id="6068084" data-element_type="section">
              <div class="elementor-container elementor-column-gap-default">
                <div
                  class="has_eae_slider elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-8b30152"
                  data-id="8b30152" data-element_type="column">
                  <div class="elementor-widget-wrap elementor-element-populated">
                    <div class="elementor-element elementor-element-0ba7965 elementor-widget elementor-widget-heading"
                      data-id="0ba7965" data-element_type="widget" data-widget_type="heading.default">
                      <div class="elementor-widget-container">
                        <h2 class="elementor-heading-title elementor-size-default">Высокое качество</h2>
                      </div>
                    </div>
                    <div
                      class="elementor-element elementor-element-005ece2 elementor-widget elementor-widget-text-editor"
                      data-id="005ece2" data-element_type="widget" data-widget_type="text-editor.default">
                      <div class="elementor-widget-container">
                        <p style="text-align: center;">Работы ведутся на лучшем оборудовании из Италии, США, России.</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="has_eae_slider elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-592ecce"
                  data-id="592ecce" data-element_type="column">
                  <div class="elementor-widget-wrap elementor-element-populated">
                    <div class="elementor-element elementor-element-2058060 elementor-widget elementor-widget-heading"
                      data-id="2058060" data-element_type="widget" data-widget_type="heading.default">
                      <div class="elementor-widget-container">
                        <h2 class="elementor-heading-title elementor-size-default">Предварительная запись</h2>
                      </div>
                    </div>
                    <div
                      class="elementor-element elementor-element-c938db0 elementor-widget elementor-widget-text-editor"
                      data-id="c938db0" data-element_type="widget" data-widget_type="text-editor.default">
                      <div class="elementor-widget-container">
                        <p>Клиентам из Белгородской, Орловской и Курской областей, изготовление заказа в 1 день.</p>
                      </div>
                    </div>
                    <div
                      class="elementor-element elementor-element-5d73cd8 elementor-widget elementor-widget-text-editor"
                      data-id="5d73cd8" data-element_type="widget" data-widget_type="text-editor.default">
                      <div class="elementor-widget-container">
                        <p><span style="color: #ff0000;">8 (4712) 32-48-30; </span><span
                            style="color: #ff0000;">8-910-731-10-07</span></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="has_eae_slider elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-a8a4d01"
                  data-id="a8a4d01" data-element_type="column">
                  <div class="elementor-widget-wrap elementor-element-populated">
                    <div class="elementor-element elementor-element-f76255f elementor-widget elementor-widget-heading"
                      data-id="f76255f" data-element_type="widget" data-widget_type="heading.default">
                      <div class="elementor-widget-container">
                        <h2 class="elementor-heading-title elementor-size-default">С нами удобно работать</h2>
                      </div>
                    </div>
                    <div
                      class="elementor-element elementor-element-dabe94d elementor-widget elementor-widget-text-editor"
                      data-id="dabe94d" data-element_type="widget" data-widget_type="text-editor.default">
                      <div class="elementor-widget-container">
                        <p style="text-align: center;">Компания ведет работу с различными формами оплаты. Наличный
                          расчет. Безналичный расчет с НДС и без НДС.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section><?php /**PATH C:\Users\LisaN\Documents\GitHub\shlifovka\resources\views/part/preim.blade.php ENDPATH**/ ?>