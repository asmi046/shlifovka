<section
class="has_eae_slider elementor-section elementor-top-section elementor-element elementor-element-114c1f7 elementor-section-content-middle elementor-section-stretched elementor-section-full_width elementor-section-height-default elementor-section-height-default"
data-id="114c1f7" data-element_type="section"
data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
<div class="elementor-container elementor-column-gap-default">
  <div
    class="has_eae_slider elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d6bb839"
    data-id="d6bb839" data-element_type="column">
    <div class="elementor-widget-wrap elementor-element-populated">
      <div
        class="elementor-element elementor-element-41aead6 elementor-widget elementor-widget-google_maps"
        data-id="41aead6" data-element_type="widget" data-widget_type="google_maps.default">
        <div class="elementor-widget-container">
          <div class="elementor-custom-embed">
            <iframe frameborder="0" scrolling="no" marginheight="0" marginwidth="0"
              src="https://maps.google.com/maps?q=%D0%A8%D0%BB%D0%B8%D1%84%D0%BE%D0%B2%D0%BA%D0%B0%2C%20%D0%B3.%20%D0%9A%D1%83%D1%80%D1%81%D0%BA%2C%201%D1%8F%20%D0%9C%D0%BE%D0%BA%D0%B2%D0%B0%2C%20%D1%83%D0%BB.%20%D0%A1%D0%B0%D0%BD%D0%B0%D1%82%D0%BE%D1%80%D1%81%D0%BA%D0%B0%D1%8F%2C%20%D0%B4.%202&#038;t=m&#038;z=16&#038;output=embed&#038;iwloc=near"
              title="Шлифовка, г. Курск, 1я Моква, ул. Санаторская, д. 2"
              aria-label="Шлифовка, г. Курск, 1я Моква, ул. Санаторская, д. 2"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</section><?php /**PATH C:\Users\LisaN\Documents\GitHub\shlifovka\resources\views/part/map_in_main.blade.php ENDPATH**/ ?>